import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{asc, col, desc, lit, round, sum, to_date, to_timestamp}



object Project_2 {

  def US_Senators(spark:SparkSession): Unit ={
    spark.sparkContext.setLogLevel("WARN")
    val sc = spark.sparkContext
    import spark.implicits._

    val US_Senators_DF = spark.read.format("csv").option("header", true).load("input/Project2Data_USSenators.csv")
    val NY_Senator_DF = US_Senators_DF.filter(US_Senators_DF("state") === "NEW YORK")

    val party = sc.parallelize(Seq("REPUBLICAN", "SOCIALIST WORKERS", "LIBERAL", "CONSERVATIVE", "LABOR" ,"" +
      "COMMUNIST", "LIBERTARIAN", "DEMOCRAT", "FREE LIBERTARIAN", "RIGHT TO LIFE", "NEW ALLIANCE", "WORKERS WORLD", "INDEPENDENT PROGRESSIVE LINE", "" +
      "NATURAL LAW", "INDEPENDENCE FUSION", "GREEN", "MARIJUANA REFORM", "CONSTITUTION", "INDEPENDENCE", "BUILDERS", "WORKING FAMILIES", "" +
      "SOCIALIST EQUALITY", "RENT IS 2 DAMN HIGH", "TAX REVOLT", "ANTI-PROHIBITION", "COMMON SENSE", "REFORM", "WOMEN'S EQUALITY"))

    val party_DF = party.toDF("Party")
    party_DF.cache()
    val records = party_DF.join(NY_Senator_DF, col("party_detailed") === col("Party"))
    records.createOrReplaceTempView("records")
    val final_DF = spark.sql("SELECT SUM(candidatevotes), Party FROM records GROUP BY Party ORDER BY SUM(candidatevotes) DESC")
    final_DF.show()


  }
  def main(args:Array[String]): Unit = {
    /*
    Main function. Initializes the SparkSession and runs the various methods that explore different trends
     */
    val spark = SparkSession
      .builder
      .appName("p3")
      .config("spark.master", "local")
      .config("spark.sql.catalogImplementation", "hive")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .enableHiveSupport()
      .getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    US_Senators(spark)

  }

}
